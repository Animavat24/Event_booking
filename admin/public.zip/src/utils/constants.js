export const ROLES = {
  ADMIN: 'admin',
  USER: 'user'
};

export const EVENT_STATUSES = {
  UPCOMING: 'upcoming',
  ONGOING: 'ongoing',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled'
};